// stdafx.cpp : source file that includes just the standard includes
//	SYNTH.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"


#pragma comment(lib,"GLU32.LIB")
#pragma comment(lib,"OPENGL32.LIB")
#pragma comment(lib,"WSOCK32.LIB")

