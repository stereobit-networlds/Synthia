// GExternal.cpp : implementation file
//

#include "stdafx.h"
#include "SYNTH.h"
#include "SYNTHdoc.h"
#include "SYNTHView.h"
#include "GExternal.h"
#include "RoomBase.h"
#include "RoomWall.h"
#include "WorldBase.h"
#include "glib0.h"
#include "lib0.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#include <Inventor/nodes/SoCube.h>
#include <Inventor/nodes/SoMaterial.h>
#include <Inventor/nodes/SoSeparator.h>
#include <Inventor/nodes/SoNormal.h>
#include <Inventor/nodes/SoCoordinate3.h>
#include <Inventor/nodes/SoFaceSet.h>
#include <Inventor/nodes/SoNormalBinding.h>
#include <Inventor/nodes/SoText2.h>
#include <Inventor/fields/SoSFString.h>
#include <Inventor/nodes/SoTexture2.h>
#include <Inventor/nodes/SoTexture2Transform.h>
#include <Inventor/nodes/SoTextureCoordinatePlane.h>
#include <Inventor/nodes/SoComplexity.h>
#include <Inventor/nodes/SoTranslation.h>
#include <Inventor/nodes/SoRotation.h>
#include <Inventor/nodes/SoSelection.h>

#define PI 3.1415926


/////////////////////////////////////////////////////////////////////////////
// CGExternal

IMPLEMENT_DYNAMIC( CGExternal, CObject )

CGExternal::CGExternal()
{
	sep = NULL ;

	next_id = 0;
	prior_id = 0;

	CSYNTHDoc* sdoc = sview->GetDocument(); //add by me  <----------------------- !!!!!

}

CGExternal::~CGExternal()
{
}


/*======================== ObjectToInventor ================*/

void CGExternal::ObjectToInventor ( SoSeparator *root )
{
	// inherited action
	CGObject::ObjectToInventor(root) ;

	//�� ����������� ���� ����������� ������ ���� ���� 0,0,0
	GetBox();  //<<<<<-------------------------------- ������������

	SaveProperties() ;     
	root->addChild(sep) ;
  
    //check for ...
	if (sdoc->BATTERING)  //battering ...
    {
       AttachObject();
    }
	
	if (sdoc->REPLACE)    //replace ...
    {
	   ReplaceObject(); 	 
    }
} 

/*======================== SaveProperties ===================*/

void CGExternal::SaveProperties ()
{
	// inherited action
	CGObject::SaveProperties() ;
    
	sep->setName(name) ;  // set node name


	// find "Attributes"
	int mychild =sep->getNumChildren()-1;
	SoSeparator *myattr = (SoSeparator *)sep->getChild(mychild);
	const char *name = ((SoSeparator *)myattr)->getName().getString();  //get name
    
//	AfxMessageBox(name); 

	if (strcmp(name,"Attributes")==0) //Attributes exist delete it...
    {
		sep->removeChild(mychild);
    }

	SoSeparator *attr = new SoSeparator() ; //... rewrite attributes (case modify)
    attr->setName("Attributes") ;

	//set attributes invisible & unpickable...
    SoDrawStyle *ds = new SoDrawStyle ;
	attr->addChild(ds) ;
	ds->style = SoDrawStyle::INVISIBLE ;

	SoPickStyle *ps = new SoPickStyle;
	attr->addChild(ps) ;
    ps->style.setValue(SoPickStyle::UNPICKABLE) ;

  

	CLib0 lib ;
	CString soff = lib.inttostr(offset) ; 

    lib.setSoSFIntProp ( attr, SbName("ext_id"+soff), id ) ;
	lib.setSoSFStringProp ( attr, SbName("ob_code"+soff), code ) ;
	lib.setSoSFStringProp ( attr, SbName("ob_descr"+soff), descr ) ;
	
	lib.setSoSFStringProp ( attr, SbName("ob_eid0"+soff), eid_id[0] ) ;
	lib.setSoSFStringProp ( attr, SbName("ob_eid1"+soff), eid_id[1] ) ;
	lib.setSoSFStringProp ( attr, SbName("ob_eid2"+soff), eid_id[2] ) ;
	lib.setSoSFStringProp ( attr, SbName("ob_eid3"+soff), eid_id[3] ) ;
	lib.setSoSFStringProp ( attr, SbName("ob_eid4"+soff), eid_id[4] ) ;
	lib.setSoSFStringProp ( attr, SbName("ob_eid5"+soff), eid_id[5] ) ;
	lib.setSoSFStringProp ( attr, SbName("ob_eid6"+soff), eid_id[6] ) ;
	lib.setSoSFStringProp ( attr, SbName("ob_eid7"+soff), eid_id[7] ) ;
	lib.setSoSFStringProp ( attr, SbName("ob_eid8"+soff), eid_id[8] ) ;
	lib.setSoSFStringProp ( attr, SbName("ob_eid9"+soff), eid_id[9] ) ;

	lib.setSoSFIntProp ( attr, SbName("next"+soff), next_id ) ;
	lib.setSoSFIntProp ( attr, SbName("prior"+soff), prior_id ) ;
	lib.setSoSFIntProp ( attr, SbName("carrier"+soff), carrier_id ) ;
	lib.setSoSFIntProp ( attr, SbName("carrierSide"+soff), carrier_side ) ;
	lib.setSoSFIntProp ( attr, SbName("objectSide"+soff), object_side ) ;
	lib.setSoSFIntProp ( attr, SbName("outlook"+soff), outlook ) ;

	lib.setSoSFFloatProp ( attr, SbName("normal0"+soff), objNormal[0] ) ;
	lib.setSoSFFloatProp ( attr, SbName("normal1"+soff), objNormal[1] ) ;
	lib.setSoSFFloatProp ( attr, SbName("normal2"+soff), objNormal[2] ) ;
	
	lib.setSoSFFloatProp ( attr, SbName("yangle"+soff), yangle ) ;

	lib.setSoSFFloatProp ( attr, SbName("lbp0"+soff), left_base_point[0] ) ;
	lib.setSoSFFloatProp ( attr, SbName("lbp1"+soff), left_base_point[1] ) ;
	lib.setSoSFFloatProp ( attr, SbName("lbp2"+soff), left_base_point[2] ) ;
	lib.setSoSFFloatProp ( attr, SbName("rbp0"+soff), right_base_point[0] ) ;
	lib.setSoSFFloatProp ( attr, SbName("rbp1"+soff), right_base_point[1] ) ;
	lib.setSoSFFloatProp ( attr, SbName("rbp2"+soff), right_base_point[2] ) ;

	lib.setSoSFFloatProp ( attr, SbName("ltp0"+soff), left_top_point[0] ) ;
	lib.setSoSFFloatProp ( attr, SbName("ltp1"+soff), left_top_point[1] ) ;
	lib.setSoSFFloatProp ( attr, SbName("ltp2"+soff), left_top_point[2] ) ;
	lib.setSoSFFloatProp ( attr, SbName("rtp0"+soff), right_top_point[0] ) ;
	lib.setSoSFFloatProp ( attr, SbName("rtp1"+soff), right_top_point[1] ) ;
	lib.setSoSFFloatProp ( attr, SbName("rtp2"+soff), right_top_point[2] ) ;

	sep->addChild( attr ) ;
}

/*======================== InventorToObject ================*/

void CGExternal::InventorToObject ( SoSeparator *root )
{
	sep = root ;

	//inherited action
	CGObject::InventorToObject ( root );

	CLib0 lib ;
	CString soff = lib.inttostr(offset) ;

	id	       = lib.getSoSFIntProp(SbName("id"+soff)) ;
	code       = lib.getSoSFStringProp(SbName("ob_code"+soff)) ;
	descr      = lib.getSoSFStringProp(SbName("ob_descr"+soff)) ;

	eid_id[0]  = lib.getSoSFStringProp(SbName("ob_eid0"+soff)) ;
	eid_id[1]  = lib.getSoSFStringProp(SbName("ob_eid1"+soff)) ;
	eid_id[2]  = lib.getSoSFStringProp(SbName("ob_eid2"+soff)) ;
	eid_id[3]  = lib.getSoSFStringProp(SbName("ob_eid3"+soff)) ;
	eid_id[4]  = lib.getSoSFStringProp(SbName("ob_eid4"+soff)) ;
	eid_id[5]  = lib.getSoSFStringProp(SbName("ob_eid5"+soff)) ;
	eid_id[6]  = lib.getSoSFStringProp(SbName("ob_eid6"+soff)) ;
	eid_id[7]  = lib.getSoSFStringProp(SbName("ob_eid7"+soff)) ;
	eid_id[8]  = lib.getSoSFStringProp(SbName("ob_eid8"+soff)) ;
	eid_id[9]  = lib.getSoSFStringProp(SbName("ob_eid9"+soff)) ;

	next_id		= lib.getSoSFIntProp(SbName("next"+soff)) ;
	prior_id	= lib.getSoSFIntProp(SbName("prior"+soff)) ;
	carrier_id	= lib.getSoSFIntProp(SbName("carrier"+soff)) ;
	carrier_side= lib.getSoSFIntProp(SbName("carrierSide"+soff)) ;
	object_side = lib.getSoSFIntProp(SbName("objectSide"+soff)) ;
	outlook  	= lib.getSoSFIntProp(SbName("outlook"+soff)) ;

	objNormal[0] = lib.getSoSFFloatProp(SbName("normal0"+soff)) ;
	objNormal[1] = lib.getSoSFFloatProp(SbName("normal1"+soff)) ;
	objNormal[2] = lib.getSoSFFloatProp(SbName("normal2"+soff)) ;

	yangle		= lib.getSoSFFloatProp(SbName("yangle"+soff)) ;

	left_base_point[0]	= lib.getSoSFFloatProp(SbName("lbp0"+soff)) ;
	left_base_point[1]	= lib.getSoSFFloatProp(SbName("lbp1"+soff)) ;
	left_base_point[2]	= lib.getSoSFFloatProp(SbName("lbp2"+soff)) ;
	right_base_point[0]	= lib.getSoSFFloatProp(SbName("rbp0"+soff)) ;
	right_base_point[1]	= lib.getSoSFFloatProp(SbName("rbp1"+soff)) ;
	right_base_point[2]	= lib.getSoSFFloatProp(SbName("rbp2"+soff)) ;

	left_top_point[0]	= lib.getSoSFFloatProp(SbName("ltp0"+soff)) ;
	left_top_point[1]	= lib.getSoSFFloatProp(SbName("ltp1"+soff)) ;
	left_top_point[2]	= lib.getSoSFFloatProp(SbName("ltp2"+soff)) ;
	right_top_point[0]	= lib.getSoSFFloatProp(SbName("rtp0"+soff)) ;
	right_top_point[1]	= lib.getSoSFFloatProp(SbName("rtp1"+soff)) ;
	right_top_point[2]	= lib.getSoSFFloatProp(SbName("rtp2"+soff)) ;
}

void CGExternal::GetBox()
{
	SbVec3f global;

	// inherited action
	CGObject::GetBox() ;

	//assign min(xyz),max(xyz) 
	//���� ��������� ��� externals �� min,max's ����� �� �������� ������
	//��� ������������ ��� ���� ��� ������� �������������...
	//��� ���� ������� ��� global ����� ����� �� �������� �� transformation ��� obj

    //global = GetTranslation.............
	//SoSeparator *sep = ((CGObject*)obj)->sep ;
    SoTranslation *trans = (SoTranslation *)sep->getChild(1) ;
    global = trans->translation.getValue();

	/*CLib0 lib;
	AfxMessageBox(lib.floattostr(global[0])+" "+
		          lib.floattostr(global[1])+" "+
				  lib.floattostr(global[2]));
*/
	//****** down
	ssx[0] = xmin + global[0];
    ssy[0] = ymin + global[1];
	ssz[0] = zmin + global[2];

	ssx[1] = xmin + global[0];
    ssy[1] = ymin + global[1];
	ssz[1] = zmax + global[2];

	ssx[2] = xmax + global[0];
    ssy[2] = ymin + global[1];
	ssz[2] = zmax + global[2];

	ssx[3] = xmax + global[0];
    ssy[3] = ymin + global[1];
	ssz[3] = zmin + global[2];

	//****** up
	ssx[4] = xmin + global[0];
    ssy[4] = ymax + global[1];
	ssz[4] = zmin + global[2];

	ssx[5] = xmin + global[0];
    ssy[5] = ymax + global[1];
	ssz[5] = zmax + global[2];

	ssx[6] = xmax + global[0];
    ssy[6] = ymax + global[1];
	ssz[6] = zmax + global[2];

	ssx[7] = xmax + global[0];
    ssy[7] = ymax + global[1];
	ssz[7] = zmin + global[2];

}

/*======================= EditProperties ========================*/
int CGExternal::EditProperties ( CDocument *d, SoSeparator *root ) 
{
	CLib0 lib;
    float comparedistX,comparedistX1,comparedistY ; //compare purpose
	float compL , compR , compAngle ,compOut ;
	float x,y,z,r;

	// inherited action
	CGObject::EditProperties(d,root) ;

	//get selected object
	CGExternal *selected = ((CGExternal*)sdoc->Obj[sdoc->obj_selector]);

	//show attrs
	AfxMessageBox("Id "+lib.inttostr(selected->id)+"\nCarrier "
		         +lib.inttostr(selected->carrier_id)+"\n Side"
		         +lib.inttostr(selected->carrier_side)+"\n Next "
		         +lib.inttostr(selected->next_id)+"\n Previous "
				 +lib.inttostr(selected->prior_id)+"\n Outlook "
				 +lib.inttostr(selected->outlook)+"\n Normals "
				 +lib.inttostr(selected->objNormal[0])+" "
				 +lib.inttostr(selected->objNormal[1])+" "
				 +lib.inttostr(selected->objNormal[2]) );

	if ((selected->carrier_side ==_NONE_) || 
		(selected->object_side == _NOWHERE_))
	{
       AfxMessageBox("Invalid object data");
	   return 0 ;
    }

	//get the carrier reference points
	selected->GetCarrierSide();

	//get the object reference points
	selected->GetObjectSide();

    //Calculate selected object distances
    xdist = selected->GetLeftDistance(0);
	x1dist = selected->GetRightDistance(0);

	//Calculate selected object or whole battering wall distances
	Ldist = selected->GetLeftDistance(1);
	Rdist = selected->GetRightDistance(1);

	//get object height
	ydist = selected->GetDistanceY();

	//Get object rotation
	yangle = RadiansToMires( selected->GetRotationAngle() );

	GExternalProp *dlg = new GExternalProp ;

	dlg->m_code		= code ;
	dlg->m_descr	= descr ;
	dlg->m_yangle	= yangle ; compAngle = yangle ;
	dlg->m_xdist	= xdist ; comparedistX = xdist; 
	dlg->m_ydist	= ydist ; comparedistY = ydist;
	dlg->m_leftdist = Ldist ; compL = Ldist;
	dlg->m_rightdist= Rdist ; compR = Rdist;
	dlg->m_x1dist   = x1dist; comparedistX1 = x1dist;
	dlg->m_outlook  = outlook ; compOut = outlook ;

    dlg->m_objLen = selected->GetObjectLength(); 
	dlg->m_batLen = selected->GetBatteryLength(); 

	int res = dlg->DoModal() ;

	if (res == IDOK)   
	{
		sdoc->SaveUndo(); //save scene for undo...

		code	= dlg->m_code ;
		descr	= dlg->m_descr ;
		yangle	= dlg->m_yangle ;
		outlook	= dlg->m_outlook ;
        xdist   = dlg->m_xdist ; 
		ydist   = dlg->m_ydist ;
        Ldist   = dlg->m_leftdist ;
		Rdist   = dlg->m_rightdist ;
		x1dist  = dlg->m_x1dist ;

        x=xdist;
		y=ydist;
		z=outlook;
		r=MiresToRadians(yangle);

		//rotate...
		if (fabs(yangle - compAngle) > 0.01)
		{
			selected->RotateObject(r ,0);
        }

        
		// set x object (not buttering) translation
		if (fabs(xdist - comparedistX) > 0.001)
		{
			x = selected->SetLeftDistance(xdist,0);
			goto out;
		}
		if (fabs(x1dist - comparedistX1) > 0.001) 
		{
		    x = selected->SetRightDistance(x1dist,0);
			goto out;
		}
        // set x object or battering translation 
		if (fabs(Ldist - compL) > 0.001) 
		{
		    x = selected->SetLeftDistance(Ldist,1);
			goto out;
        }
		if (fabs(Rdist - compR) > 0.001)
		{
			x = selected->SetRightDistance(Rdist,1);
			goto out;
		}

		
out: ;  //move...
        selected->MoveObjectTo(x,y,z) ;
	
		SaveProperties() ;    
	}

	return res ;
}

/*************************  find side  ********************/

void CGExternal::FindCarrierSide(SbVec3f click_point)
{
	CLib0 lib;
	int mycarrier , simia ,  counter ,side[4];

	mycarrier = carrier_id;
	//AfxMessageBox(lib.inttostr(mycarrier));

	CGObject *obj = ((CGObject*)sdoc->Obj[mycarrier]);

	//get points data x1,y1,z1 ,x2,y2,z2
	if (obj->IsKindOf(RUNTIME_CLASS(CWorldBase)))
	{	
       //do nothing for now...
	}
	else 
	if (obj->IsKindOf(RUNTIME_CLASS(CRoomBase)))
    {
       //do nothing for now...
    }
	else
	if (obj->IsKindOf(RUNTIME_CLASS(CRoomWall)))
	{
        CRoomWall *rw = ((CRoomWall*)obj);

		counter = 0;

		for (simia=0 ; simia<8 ; simia ++) //��� ����������� ���� 8 ������  ������ ��� �� �����������
        {
           if ( (fabs(click_point[0] - rw->Koryfsx[simia]) < 0.01 ) ||
			    (fabs(click_point[1] - rw->Koryfsy[simia]) < 0.01 ) ||
			    (fabs(click_point[2] - rw->Koryfsz[simia]) < 0.01 ) )
           {
               //that is reference point
			   side[counter]=simia; 
			   counter+=1;
           }
		}
		// ���� ������� �������� ��� ������ ��� ������� ��� ��� ���� ��� ���� ��� ��� ������ ���

		if (IsArrayEqual(front , side)) carrier_side = _FRONT_;
		else
		if (IsArrayEqual(left , side)) carrier_side = _LEFT_;
		else
        if (IsArrayEqual(back , side)) carrier_side = _BACK_;
		else
		if (IsArrayEqual(right , side)) carrier_side = _RIGHT_;
		else
		if (IsArrayEqual(top , side)) carrier_side = _TOP_;
		else
		if (IsArrayEqual(bottom , side)) carrier_side = _BOTTOM_;
		else
           carrier_side = _NOWHERE_;

        AfxMessageBox(lib.inttostr(side[0])+" "+
		              lib.inttostr(side[1])+" "+
		         	  lib.inttostr(side[2])+" "+
					  lib.inttostr(side[3])+"\n"+
    				  lib.inttostr(carrier_side) );
    }
	else        
	if (obj->IsKindOf(RUNTIME_CLASS(CGExternal)))
	{
	    //do nothing 
    }
	
	
	/*AfxMessageBox("Ref points "+lib.floattostr(pointX1)+" "+
		                        lib.floattostr(pointY1)+" "+
				                lib.floattostr(pointZ1));*/
}


void CGExternal::AddNewObject(SbVec3f p_point, SbVec3f p_normal)
{
	    CLib0 lib ;

		// inherited action
	    CGObject::AddNewObject(p_point,p_normal) ;

		CGExternal *ext = ((CGExternal*)sdoc->Obj[sdoc->ObjCount-1]) ;
		SoSeparator *ext_sep = ((CGExternal*)sdoc->Obj[sdoc->ObjCount-1])->sep ;

		ext->MakeObjVisible();
		ext->SetTranslation(p_point);

		SoRotation *rot	= (SoRotation *)ext_sep->getChild(2) ;   
		SbRotation *sbrot = new SbRotation(SbVec3f(0,0,1),p_normal) ;
		rot->rotation.setValue(*sbrot) ;

		//get box with the click point translation
		//������ �� ����������� ��� ����������� ���� ���� � ������...
		//������������� ��� ���������� ��� ���� �� click...
		ext->GetBox();   //<<<<<-------------------------------- ������������

        //set carrier
	    ext->carrier_id = sdoc->obj_selector ;
		//object's side
		ext->object_side = _BACK_; //<<<<------------ = default side
		//set projection
		ext->outlook = 0;

		ext->FindCarrierSide(p_point); //?????????????????????????? error

		//get object normal 
		ext->objNormal[0] = p_normal[0]; 
		ext->objNormal[1] = p_normal[1];  
		ext->objNormal[2] = p_normal[2];  


	    ext->SaveProperties();

		sdoc->new_object = _NONE_ ; 
		
		//select it..
		sview->GetSelectionNode()->deselectAll();
		sview->GetSelectionNode()->select(ext_sep->getChild(4)) ; //get "geometry" node
		sdoc->obj_selector = sdoc->ObjCount-1 ;

		//.. and set battering on..
		sdoc->BATTERING = true;
}




//get matrix
SbMatrix CGExternal::GetObjectMatrix()
{   
    SbVec3f Raxis ;
	float Rangle ;
	SbMatrix matrix;

	SoSeparator *mysep = sep ;

	SoRotation *ext_r = (SoRotation *)mysep->getChild(2) ;
	ext_r->rotation.getValue(Raxis , Rangle); 

	SbRotation *sbrot = new SbRotation(Raxis , Rangle); 
	sbrot->getValue(matrix); 

	return matrix;
}


//get object vectors
SbVec3f CGExternal::GetObjectVectors()
{
	SbVec3f p1 , p2, dianisma ;

	//get left and right base points of selected object
    //CGExternal *ext = ((CGExternal*)e_obj);
/*    p1[0] = ext->left_base_point[0] ;
    p1[1] = ext->left_base_point[1] ;
    p1[2] = ext->left_base_point[2] ;

    p2[0] = ext->right_base_point[0] ;
    p2[1] = ext->right_base_point[1] ;
    p2[2] = ext->right_base_point[2] ;
*/
	p1[0] = ssx[0] ;
    p1[1] = ssy[0] ;
    p1[2] = ssz[0] ;

    p2[0] = ssx[3] ;
    p2[1] = ssy[3] ;
    p2[2] = ssz[3] ;


    //get distances
    dianisma[0] = p2[0] - p1[0];
    dianisma[1] = p2[1] - p1[1];
    dianisma[2] = p2[2] - p1[2]; 
			   
	return dianisma ;
}

SbVec3f CGExternal::GetObjectDirection(SbVec3f source)
{
	SbMatrix mymatrix;
	SbVec3f target ;

	//multiply dianisma by matrix 
	mymatrix = GetObjectMatrix();
    mymatrix.multVecMatrix(source , target);

	return target ;
}


float CGExternal::GetBatteryLength()
{
	float len , len1, len2, Lsum ,Rsum , sum;
    int my_prev , my_next ;
   
	Lsum = Rsum = 0 ;

	len = GetObjectLength();

	my_prev = prior_id ;
    
    while (my_prev!=0)
	{
       CGExternal *prv = ((CGExternal*)sdoc->Obj[my_prev]);  //get previous object 

	   //get prev object
	   my_prev = prv->prior_id ;
       len1 = prv->GetObjectLength();
	   Lsum = Lsum + len1; 
	}

	my_next = next_id ;

    while (my_next!=0)
	{
       CGExternal *nxt = ((CGExternal*)sdoc->Obj[my_next]);  //get next object 

	   //get next object
	   my_next = nxt->next_id ;
	   len2 = nxt->GetObjectLength();
	   Rsum = Rsum + len2;
	}
    sum = (len + Lsum + Rsum); 

	return sum ;
}


//get object x distance 
float CGExternal::GetDistanceX()
{
    CLib0 lib;
	float objX,objY,objZ ;
	float d,f,d1; 
	SbVec3f vals;

	SoSeparator *mysep = sep ; //get node
	SoNode *mynode ;
	mynode = mysep->getChild(1);
	if (mynode->isOfType(SoTranslation::getClassTypeId())) //if it is translation node
    {     
      SoTranslation *trans = (SoTranslation *) mynode ; //get translation node
	  vals = trans->translation.getValue(); //get values
	  
	  objX = vals[0];
      objY = vals[1];
      objZ = vals[2];

	  //AfxMessageBox("object :"+lib.floattostr(vals[0])+" "+lib.floattostr(vals[1])+" "+lib.floattostr(vals[2]));

	  //begin calculations...
	  //step 1 : calc d
      d = sqrt( (pow( (objX - pointX1), 2)) +  
		        (pow( (objY - pointY1), 2)) + 
				(pow( (objZ - pointZ1), 2)) );
	  d = fabs(d);
      //step 2 : calc f =cos(f)
      f = ( ( ((pointX2 - pointX1)*(objX - pointX1)) +
		      ((pointY2 - pointY1)*(objY - pointY1)) +
			  ((pointZ2 - pointZ1)*(objZ - pointZ1)) ) /
            ( fabs(d) *
			  sqrt( (pow( (pointX2 - pointX1), 2)) +
			        (pow( (pointY2 - pointY1), 2)) +
					(pow( (pointZ2 - pointZ1), 2)) )
			)
		  );
	  
	  //finally step 3 : calc d1 
      d1 = ( ( ((pointX2 - pointX1)*(objX - pointX1)) +
		       ((pointY2 - pointY1)*(objY - pointY1)) +
			   ((pointZ2 - pointZ1)*(objZ - pointZ1)) ) /
              ( sqrt( (pow( (pointX2 - pointX1), 2)) +
			          (pow( (pointY2 - pointY1), 2)) +
					  (pow( (pointZ2 - pointZ1), 2)) )
		      )
			);
	  //step 4 : calc d2
	  //d2 = ( fabs(d) * ( cos( (PI/2) - acos(f) ) ) );


	  //d1 = fabs(d1);
	  //d2 = fabs(d2);
      
	  return d1;
    }
	else
    {
	  AfxMessageBox("Unable to translate the object.");
	  return 0;
    }

}

//get object y distance (height down)
float CGExternal::GetDistanceY()
{
    CLib0 lib;
	float objX,objY,objZ ;
	float d,f,d2,t; 
	SbVec3f vals;

	SoSeparator *mysep = sep ; //get node
	SoNode *mynode ;
	mynode = mysep->getChild(1);
	if (mynode->isOfType(SoTranslation::getClassTypeId())) //if it is translation node
    {     
      SoTranslation *trans = (SoTranslation *) mynode ; //get translation node
	  vals = trans->translation.getValue(); //get values
	  
	  objX = vals[0];
      objY = vals[1];
      objZ = vals[2];
	  //������ �� ���������� �� projection
	  //����� �� ����������� �������� ���� ��� ������� ��� carrier
      objX = objX - (objNormal[0] * outlook) ;
	  objY = objY - (objNormal[1] * outlook) ;
	  objZ = objZ - (objNormal[2] * outlook) ;

	  //AfxMessageBox("object :"+lib.floattostr(vals[0])+" "+lib.floattostr(vals[1])+" "+lib.floattostr(vals[2]));

	  //begin calculations...
	  //step 1 : calc d
      d = sqrt( (pow( (objX - pointX1), 2)) +  
		        (pow( (objY - pointY1), 2)) + 
				(pow( (objZ - pointZ1), 2)) );
	  d = fabs(d);
      //step 2 : calc f =cos(f)
      f = ( ( ((pointX2 - pointX1)*(objX - pointX1)) +
		      ((pointY2 - pointY1)*(objY - pointY1)) +
			  ((pointZ2 - pointZ1)*(objZ - pointZ1)) ) /
            ( fabs(d) *
			  sqrt( (pow( (pointX2 - pointX1), 2)) +
			        (pow( (pointY2 - pointY1), 2)) +
					(pow( (pointZ2 - pointZ1), 2)) )
			)
		  );
	  
	  //step 3 : calc d2
	  t = ( cos( (PI/2) - acos(f) ) );
	  d2 = ( fabs(d) * t );

	  //d1 = fabs(d1);
	  //d2 = fabs(d2);
      
	  if (d2 < 1.0) d2 = 0.5; //minimum

	  return d2;
    }
	else
    {
	  AfxMessageBox("Unable to translate the object.");
	  return 0;
    }

}



//get object x' distance from wall limit (right distance)
float CGExternal::GetRightDistance(int param)
{
	float d1 ,d2 ,carrier_length , objLength;
	int my_next ;

	d1             = GetDistanceX();
    objLength      = GetObjectLength();
	carrier_length = GetCarrierLength();

	d2 = carrier_length - d1 - objLength;

	if (param)
    {
	//if battering ... find the very next distances 
	my_next = next_id ;
	while (my_next!=0)
	{
       CGExternal *nxt = ((CGExternal*)sdoc->Obj[my_next]);  //get next object
	   
	   //get next object
	   my_next = nxt->next_id ;

	   d1 = nxt->GetDistanceX();
       objLength = nxt->GetObjectLength();

	   d2 = carrier_length - d1 - objLength;
	}
    }  
	return d2;
}

//get object x distance from wall limit (left distance)
float CGExternal::GetLeftDistance(int param)
{
	float d1 ;
	int my_prev ;

	d1 = GetDistanceX() ;
      
    if (param)
    {
	//if battering ... find the very next distances 
	my_prev = prior_id ;

    while (my_prev!=0)
	{
       CGExternal *prv = ((CGExternal*)sdoc->Obj[my_prev]);  //get previous object 

	   //get prev object
	   my_prev = prv->prior_id ;

	   d1 = prv->GetDistanceX(); 
	}
    }
	return d1;
}


//set object x' distance from wall limit (right distance)
float CGExternal::SetRightDistance(float val,int param)
{
	float d1 ,carrier_length , objLength, objLength2, objLsum;
	int my_next ;

    objLength = GetObjectLength();
	carrier_length = GetCarrierLength();

	d1 = carrier_length - val - objLength;


	if (param)
    {
	//if battering ... find the very next distances 
	my_next = next_id ;
	objLsum = 0;
	while (my_next!=0)
	{
       CGExternal *nxt = ((CGExternal*)sdoc->Obj[my_next]);  //get next object
	   
	   //get next object
	   my_next = nxt->next_id ;

	   objLength2 = nxt->GetObjectLength();
	   objLsum = objLsum + objLength2 ;

	   //objLength = length of selected object / objLsum = sum length of the others
	   d1 = carrier_length - val - objLsum - objLength; 
	}
    }
	return d1;
}

//set object x distance from wall limit (left distance)
float CGExternal::SetLeftDistance(float val,int param)
{
	float d1 ,objLsum ,objLength;
	int my_prev ;

	d1 = val ;
      
	if (param)
    {
	//if battering ... 
	my_prev = prior_id ;
    objLsum = 0;
    while (my_prev!=0)
	{
       CGExternal *prv = ((CGExternal*)sdoc->Obj[my_prev]);  //get next object 

	   //get prev object
	   my_prev = prv->prior_id ;

	   objLength = prv->GetObjectLength();
	   objLsum = objLsum + objLength ;
	   d1 = val + objLsum ;
	}
    }
	return d1;
}


/********************* Move object **************************/
void CGExternal::MoveObjectTo(float d1,float d2,float d3)
{
    CLib0 lib;
	float objX,objY,objZ ;
	float b; 
	SbVec3f vector ;

	//calculations...
	b = sqrt( (pow( (pointX2 - pointX1), 2)) +  
		      (pow( (pointY2 - pointY1), 2)) + 
			  (pow( (pointZ2 - pointZ1), 2)) );

    //set x y translation
    objX = ( ( (pointX2 - pointX1) / fabs(b) ) * d1 + pointX1 ) ;
    objY = ( ( (pointY2 - pointY1) / fabs(b) ) * d1  + d2 + pointY1 ) ;
	objZ = ( ( (pointZ2 - pointZ1) / fabs(b) ) * d1 + pointZ1 ) ;

	//set projection (z trnaslation) = outlook
    objX = (objNormal[0] * d3) + objX ;
	objY = (objNormal[1] * d3) + objY ;
	objZ = (objNormal[2] * d3) + objZ ;

	//put new translation
	vector.setValue(objX , objY , objZ);
	SetTranslation(vector);

	//move all the others battering objects
	MovRebuildButtering();
}


//move all the battering objects...
//ext = the selected object of battering 
void CGExternal::MovRebuildButtering()
{
	int my_next, my_prev , my_outlook ,meter;
	SbVec3f sourcevec , targetvec , Length , dirLength;

	//get translation
    sourcevec = GetTranslation(); //���� ������� ��� �� translation ��� ���� ��� ��� ����

	my_next    = next_id ;  //get the selected object next number
	my_prev    = prior_id ;  //get the selected object previous number
	my_outlook = outlook ; //get projection

	//init calculations for the next pointers
	Length    = GetObjectVectors();
	dirLength = GetObjectDirection(Length);

	if ((my_next)!=0) targetvec = sourcevec + dirLength ; 

	//first move right objects of battering
	meter=0;
    while (my_next!=0)
	{
       CGExternal *nxt = ((CGExternal*)sdoc->Obj[my_next]);  //get next object

	   //get next object
	   my_next = nxt->next_id ;

	   //put new translation for each object
	   nxt->SetTranslation(targetvec);

	   //after calculate...
	   //calculate its distance and add it to the targetvec
	   Length = nxt->GetObjectVectors();
	   dirLength = nxt->GetObjectDirection(Length);

       targetvec = targetvec + dirLength ;

       nxt->outlook = my_outlook; //save projection
	   nxt->SaveProperties();
	   meter+=1; 
	}

	//??????????????????????????
	//init calculations for the prev pointers
	Length    = GetObjectVectors();
	dirLength = GetObjectDirection(Length);

	if ((my_prev)!=0) targetvec = sourcevec ; //=sourcevec

	//secontary move left objects...
    meter=0;
	while (my_prev!=0)
	{
       CGExternal *prv = ((CGExternal*)sdoc->Obj[my_prev]);  //get previous object
	   
	   //get prev object
	   my_prev = prv->prior_id ;

	   //first calculate...
       //calculate its distance and substrack it from the targetvec
	   Length = prv->GetObjectVectors();
	   dirLength = prv->GetObjectDirection(Length);

       targetvec = targetvec - dirLength ;

	   //put new translation for each object
	   prv->SetTranslation(targetvec);

	   prv->outlook = my_outlook; //save projection
	   prv->SaveProperties();
	   meter+=1;
	}
}
//***************************************************************************

//rotate the object(s) (with different ways if buttering)
void CGExternal::RotateObject(float angle,int typeof)
{
	int my_next, my_prev ;
	SbVec3f values , Lv , Rv;
	int meter ;
	CLib0 lib;

	//case 0 = ���������� ���� ��� ����������� ������������
	//�� �������� ����������� ����� ���������� ��� �������� ��� ����������
	SetRotationAngle(angle);

    //if battering...
	switch (typeof)
    {
	   case 0 : {
		          //do nothing 
		          //���������� � �������� ������ � ���� ����� �����
		          //��� ���� ��� �����������
		          break;
				}
	   case 1 : {
		          //�� �������� ����������� ������ ���� ����� ����� 
		          //�� ������� � ���������� ����
	              MovRebuildButtering();
	              break;
				}
       case 2 : {
		          //�� �������� ����������� ��������������  
		          //���� �� ����������
	              my_next = next_id ;  //get the selected object next number
	              my_prev = prior_id ;  //get the selected object previous number
	              meter=0;

                  while (my_next!=0)
				  {
                    CGExternal *nxt = ((CGExternal*)sdoc->Obj[my_next]);  //get next object 

	                //get next object
	                my_next = nxt->next_id ;
	                nxt->SetRotationAngle(angle);
	                meter+=1; 
				  }

                  meter=0;
	              while (my_prev!=0)
				  {
                    CGExternal *prv = ((CGExternal*)sdoc->Obj[my_prev]);  //get previous object
	   
	                //get prev object
	                my_prev = prv->prior_id ;
	                prv->SetRotationAngle(angle);
	                meter+=1;
				  }
				  break;
				}

	   default : break;
	}
}


//************************************************************


//************** input object (battering) **************/
void CGExternal::AttachObject()
{
	CLib0 lib;
    SbVec3f Transaxis , NewTransaxis , Rotaxis ,Length ,dirLength;
	float Rotangle;
	SbMatrix mymatrix ;

//  AfxMessageBox(lib.inttostr(sdoc->obj_selector));

	SoSeparator *obj_sep = sep;  //get new object sep
	CGExternal *ext = ((CGExternal*)sdoc->Obj[sdoc->obj_selector]); //get selected object

    //get selected object translation & rotation
    Transaxis = ext->GetTranslation();
	Rotaxis   = ext->GetRotationAxis();
	Rotangle  = ext->GetRotationAngle();

	//calculate translation
	switch (theApp.ObjDirection)
    {
	  case 1 : { //right
		       //get selected object distance
			   Length = ext->GetObjectVectors();
	           dirLength = ext->GetObjectDirection(Length);

		       //new translation
	           NewTransaxis[0] = Transaxis[0] + dirLength[0] ;
               NewTransaxis[1] = Transaxis[1] + dirLength[1] ;
               NewTransaxis[2] = Transaxis[2] + dirLength[2] ;

			   //AfxMessageBox("Right");
			   break;
             }
      case 2 : { //left
		       //get new object distance
		       //CGExternal *gext = ((CGExternal*)sdoc->Obj[sdoc->ObjCount-1]);
               /*?????*/
			   Length = GetObjectVectors();
 /*ext---->>>*/dirLength = ext->GetObjectDirection(Length); //get selected (ext) direction
	
               //new translation 
	           NewTransaxis[0] = Transaxis[0] - dirLength[0] ;
               NewTransaxis[1] = Transaxis[1] - dirLength[1] ;
               NewTransaxis[2] = Transaxis[2] - dirLength[2] ;

			   //AfxMessageBox("Left");
			   break;
             }
    }
	//rebuild battering (if there are battering) inserting mode
	InsRebuildButtering();

	//set new object translation & rotation 
    SoDrawStyle	*ds = (SoDrawStyle *)obj_sep->getChild(0) ;
	SoTranslation *trans = (SoTranslation *)obj_sep->getChild(1) ;
	SoRotation *rot	= (SoRotation *)obj_sep->getChild(2) ;

	ds->style = SoDrawStyle::FILLED ;
	trans->translation	= NewTransaxis ; //put new (computed ) translation values
	rot->rotation.setValue(Rotaxis ,Rotangle) ; //put rotation values same as selected object


	sdoc->new_object = _NONE_;  //��� ���������� �� ������� click ��� �� ���������� �� �����������

    //select the new object..
	sdoc->obj_selector = sdoc->ObjCount-1 ;

	sview->GetSelectionNode()->deselectAll();
	sview->GetSelectionNode()->select(obj_sep->getChild(4)) ; //get "geometry" node
	//.. and set battering on..
	sdoc->BATTERING = true;
 
	sdoc->SetModifiedFlag() ;
	sdoc->UpdateAllViews(NULL);  
}

//******* standart change of attributes  (end of battering) *******
void CGExternal::InsChangeAttributes()
{
	CGExternal *ext = ((CGExternal*)sdoc->Obj[sdoc->obj_selector]);

	//COMMON DATA
	//set carrier
	carrier_id	= ext->carrier_id ; 
	//set carrier side
	carrier_side = ext->carrier_side ;
	//other data
    outlook = ext->outlook;
    objNormal[0] = ext->objNormal[0];
    objNormal[1] = ext->objNormal[1];
    objNormal[2] = ext->objNormal[2];

	switch (theApp.ObjDirection)
    {
	  case 1 : { //right

	             //change new object attributes 

                 //set next pointer
	             next_id = 0 ; //nothing next
                 //set prior pointer
	             prior_id = sdoc->obj_selector ; //= � ������� ��� ����������� object

	             //SaveProperties(); save after...
 
	             //change selected object attributes
	             //set next pointer
	             ext->next_id = sdoc->ObjCount-1 ; //= � ������� ��� ���� object
	             // no prior
	             // no carrier
	             ext->SaveProperties();

				 break;
			   }
      case 2 : { //left

	             //change new object attributes

                 //set next pointer
	             next_id = sdoc->obj_selector ; //= � ������� ��� ����������� object
                 //set prior pointer
	             prior_id = 0 ; //nothing previous
	
	             //SaveProperties(); save after

	             //change selected object attributes
	             //set previous pointer
	             ext->prior_id = sdoc->ObjCount-1 ; //= � ������� ��� ���� object
	             // no next
	             // no carrier
	             ext->SaveProperties();

				 break;
			   }
    }

	SaveProperties(); //now save the new object data
}

//******* change of attributes in the middle of the battering *******
void CGExternal::InsChangeMiddleAttributes()
{
    CGExternal *ext = ((CGExternal*)sdoc->Obj[sdoc->obj_selector]); //get selected object

	//COMMON DATA
	//set carrier
	carrier_id	= ext->carrier_id ;
	//set carrier side
	carrier_side = ext->carrier_side ;
	//other data
    outlook = ext->outlook;
    objNormal[0] = ext->objNormal[0];
    objNormal[1] = ext->objNormal[1];
    objNormal[2] = ext->objNormal[2];

	switch (theApp.ObjDirection)
    {
	  case 1 : { //right
                 CGExternal *nxt = ((CGExternal*)sdoc->Obj[ext->next_id]);       //get next of selected object

	             //change new object attributes

                 //set next pointer
	             next_id = ext->next_id ; //the next of new object is now the next of selected
                 //set prior pointer
	             prior_id = sdoc->obj_selector ; //= � ������� ��� ����������� object

	
                 //SaveProperties();

	             //change selected object attributes
	             //set next pointer
	             ext->next_id = sdoc->ObjCount-1 ; //= � ������� ��� ���� object
	             // no prior
	             // no carrier
	             ext->SaveProperties();

	             //change next of selected (before rebuilding) object attributes
	             //no next (is the same)
	             //no carrier
	             //set previous pointer
	             nxt->prior_id = sdoc->ObjCount-1 ; //= � ������� ��� ���� object

	             nxt->SaveProperties();

				 break;
			   }
      case 2 : { //left
                 CGExternal *prv = ((CGExternal*)sdoc->Obj[ext->prior_id]);       //get previous of selected object

	             //change new object attributes

                 //set next pointer
	             next_id = sdoc->obj_selector ; //= � ������� ��� ����������� object
                 //set prior pointer
	             prior_id = ext->prior_id ; //the previous of new object is now the previous of selected   

                 //SaveProperties();

	             //change selected object attributes
	             //set previous pointer
	             ext->prior_id = sdoc->ObjCount-1 ; //= � ������� ��� ���� object
	             // no next
	             // no carrier
	             ext->SaveProperties();

	             //change previous of selected (before rebuilding) object attributes
	             //no previous
	             //no carrier
	             //set next pointer
	             prv->next_id = sdoc->ObjCount-1 ; //= � ������� ��� ���� object

	             prv->SaveProperties();

				 break;
			   }
    }

	SaveProperties(); //save new object data...
}

//rebuild the battering objects at right and left or change the attributes
//insert mode ....
void CGExternal::InsRebuildButtering()
{
    int my_next, my_prev, meter;
	SbVec3f Values , NewValues ;
	SbVec3f Length ,dirLength;

    CGExternal *e_ext = ((CGExternal*)sdoc->Obj[sdoc->obj_selector]); //get selected object

	/*????*/
	Length = GetObjectVectors(); //new object distance
	dirLength = e_ext->GetObjectDirection(Length); //�'���� ��� ��������� ��������� �� direction ��� ����������� ��� Attach...

	meter=0; //zero meter
	switch (theApp.ObjDirection)
    {
	  case 1 : { //right

                 my_next	= e_ext->next_id ;  //get the selected object next number

	             while (my_next!=0)
				 {
                    CGExternal *nxt = ((CGExternal*)sdoc->Obj[my_next]);  //get next object
					Values = nxt->GetTranslation();

	                //new translation
                    NewValues[0] = Values[0] + dirLength[0] ;
                    NewValues[1] = Values[1] + dirLength[1];
                    NewValues[2] = Values[2] + dirLength[2];

                    //put new (computed ) translation values to next object
					nxt->SetTranslation(NewValues);

	                //get next object
	                my_next = nxt->next_id ;
	                meter+=1; 
				 }
				 break;
			   }
      case 2 : { //left

                 my_prev = e_ext->prior_id ;  //get the selected object prior number

	             while (my_prev!=0)
				 {
                    CGExternal *prv = ((CGExternal*)sdoc->Obj[my_prev]);  //get previous object
                    Values = prv->GetTranslation();

                    //new translation
                    NewValues[0] = Values[0] - dirLength[0];
                    NewValues[1] = Values[1] - dirLength[1];
                    NewValues[2] = Values[2] - dirLength[2];

                    //put new (computed ) translation values to previous object
					prv->SetTranslation(NewValues);

					//get next object
	                my_prev = prv->prior_id ;
	                meter+=1;
				 }
				 break;
               }
	}

	//CLib0 lib;
	//AfxMessageBox(lib.inttostr(meter));

    //Change the attributes of objects
	if (meter==0) //it means that the new object is located at the end of battering
    {
       InsChangeAttributes();
    }
	else  //the object has insert somewhere -in- the  battering
    {
	   InsChangeMiddleAttributes();
    }
}




//******* Delete mode .. change attributes *********
void CGExternal::DelChangeAttributes()
{
	if (next_id!=0)
    {
      CGExternal *nxt = ((CGExternal*)sdoc->Obj[next_id]);       //get next of selected object
      nxt->prior_id = prior_id;
	  nxt->SaveProperties();
    }
    if (prior_id!=0)
    {
      CGExternal *prv = ((CGExternal*)sdoc->Obj[prior_id]);      //get prev of selected object 
	  prv->next_id = next_id;
      prv->SaveProperties();
    }

	//change selected (deleted) object attributes
	next_id = 0;
	prior_id = 0;
	carrier_id = 0;
	carrier_side = _NONE_ ;
	object_side = _NOWHERE_ ;
	SaveProperties();

}


//rebuild the battering objects at right or left and change the attributes
//delete mode...
//**** this routine called from delete routine of synthview file ******
void CGExternal::DelRebuildButtering()
{
    int my_next, my_prev, meter;
	SbVec3f Values , NewValues ;
	int the_next, the_prev;
    SbVec3f dirLength ,Length;

	//check if there are battering ...
	the_next = next_id ;   //get the selected object next number
    the_prev = prior_id ;  //get the selected object previous number

    if ((the_next!=0) || (the_prev!=0))
    {
      Length    = GetObjectVectors();
	  dirLength = GetObjectDirection(Length); 

	  meter=0; //zero meter
	  switch (theApp.ObjDirection)
	  {
	    case 1 : { //right

                   my_next	= next_id ;  //get the selected object next number

	               while (my_next!=0)
				   {
                      CGExternal *nxt = ((CGExternal*)sdoc->Obj[my_next]);  //get next object

					  Values = nxt->GetTranslation();

	                  //new translation
                      NewValues[0] = Values[0] - dirLength[0] ;
                      NewValues[1] = Values[1] - dirLength[1] ;
                      NewValues[2] = Values[2] - dirLength[2] ;

					  nxt->SetTranslation(NewValues);

	                  //get next object
	                  my_next = nxt->next_id ;
	                  meter+=1; 
				   }
				   break;
				 }
        case 2 : { //left

                   my_prev = prior_id ;  //get the selected object prior number

	               while (my_prev!=0)
				   {
                      CGExternal *prv = ((CGExternal*)sdoc->Obj[my_prev]);  //get previous object
	                  
					  Values = prv->GetTranslation();

                      //new translation
                      NewValues[0] = Values[0] + dirLength[0] ;
                      NewValues[1] = Values[1] + dirLength[1];
                      NewValues[2] = Values[2] + dirLength[2] ;

					  prv->SetTranslation(NewValues);

					  //get prev object
	                  my_prev = prv->prior_id ;
	                  meter+=1;
				   }
				   break;
				 }
	  }

      //Change the attributes of objects
      DelChangeAttributes();

	} //if
}



//******* Extented Delete mode .. change attributes (break battering) *********
void CGExternal::ExtDelChangeAttributes()
{
	if (next_id!=0)
    {
      CGExternal *nxt = ((CGExternal*)sdoc->Obj[next_id]);       //get next of selected object
      nxt->prior_id = 0; //break..
	  nxt->SaveProperties();
    }
    if (prior_id!=0)
    {
      CGExternal *prv = ((CGExternal*)sdoc->Obj[prior_id]);      //get prev of selected object 
	  prv->next_id = 0; //break..
      prv->SaveProperties();
    }

	//change selected (deleted) object attributes
	next_id = 0;
	prior_id = 0;
	carrier_id = 0;
	carrier_side = _NONE_ ;
	object_side = _NOWHERE_ ;
	SaveProperties();
}


//rebuild the battering objects at right or left and change the attributes
//delete object and break the battering in 2 butterings
//extent delete mode...
//**** this routine called from delete routine of synthview file ******
void CGExternal::ExtDelRebuildButtering()
{
	int the_next, the_prev;

	//check if there are battering ...
	the_next = next_id ;  //get the selected object next number
    the_prev = prior_id ;  //get the selected object previous number

    if ((the_next!=0) || (the_prev!=0))
    {
	  //..do nothing 
      //just set the atributes...

      //Change the attributes of objects
      ExtDelChangeAttributes();

	} //if
}


//delete object from battering...
void CGExternal::DelBatObject(int aanum,int mode)
{
	if (IsAttachedObject(aanum)==false)
	{
	  //rebuild the battering -before- delete the selected object
	  if (mode==0)  //select the way..  
	       DelRebuildButtering(); 
	  else ExtDelRebuildButtering();

	  DeleteObject(aanum);

	}
	else
        AfxMessageBox("          Access denied.\n Other object(s) use this object.");
}

//************** replace object  **************/
void CGExternal::ReplaceObject()
{
	int mynext,myprior,mycarrier,myoutlook,mycarrier_side,myobj_side ;
    SbVec3f Transaxis , Rotaxis ;
    float Rotangle ;
	float mynorm[3];

	SoSeparator *obj_sep = sep;  //get new object sep
	//get selected-old object ...
	CGExternal *the_old = ((CGExternal*)sdoc->Obj[sdoc->obj_selector]);//old

	//get selected-old object translation and rotation
	SoSeparator *selected = ((CGExternal*)the_old)->sep ; //get selected object node

	SoTranslation *t = (SoTranslation *)selected->getChild(1) ; 
	SoRotation *r = (SoRotation *)selected->getChild(2) ;    	
	Transaxis = t->translation.getValue(); //get selected object translation values   
    r->rotation.getValue(Rotaxis , Rotangle); //get selected object rotation values


	mynext         = the_old->next_id ;
	myprior        = the_old->prior_id ;
	mycarrier      = the_old->carrier_id ;
	mycarrier_side = the_old->carrier_side ;
	myobj_side     = the_old->object_side ;

	myoutlook = the_old->outlook;
	mynorm[0] = the_old->objNormal[0];
	mynorm[1] = the_old->objNormal[1];
	mynorm[2] = the_old->objNormal[2];

    //delete the old(replaced)-selected object
	sview->OnDelete();
	//the_old->DelBatObject(sdoc->obj_selector,0);

	if ((mynext!=0) || (myprior!=0)) //more than one object battering
    {
      switch (theApp.ObjDirection)
	  {
  	    case 1 : { //right
			       if (myprior!=0)
                   {
					   //select previous object
                      SoSeparator *p = ((CGExternal*)sdoc->Obj[myprior])->sep ;
	                  sview->GetSelectionNode()->deselectAll();
	                  sview->GetSelectionNode()->select(p->getChild(4)) ; //get "geometry" node
                      //set selector to prior object
                      sdoc->obj_selector = myprior ;

					  //Attach the object
					  AttachObject();
                   }
				   else
                   if (mynext!=0)
                   {
                      //select next object
                      SoSeparator *n = ((CGExternal*)sdoc->Obj[mynext])->sep ;
	                  sview->GetSelectionNode()->deselectAll();
	                  sview->GetSelectionNode()->select(n->getChild(4)) ; //get "geometry" node
                      //set selector to next object
                      sdoc->obj_selector = mynext ;

					  //Attach the object
					  theApp.ObjDirection=2; //switch the direction
					  AttachObject();
					  theApp.ObjDirection=1; //..and set the previous direction 
                   }
	  	           break;
				 }
        case 2 : { //left ... same as above but opposite...
			       if (mynext!=0)
                   {
                      //select next object
                      SoSeparator *n = ((CGExternal*)sdoc->Obj[mynext])->sep ;
	                  sview->GetSelectionNode()->deselectAll();
	                  sview->GetSelectionNode()->select(n->getChild(4)) ; //get "geometry" node
                      //set selector to next object
                      sdoc->obj_selector = mynext ;

					  //Attach the object
					  AttachObject();
                   }
				   else
                   if (myprior!=0)
                   {
                      //select previous object
                      SoSeparator *p = ((CGExternal*)sdoc->Obj[myprior])->sep ;
	                  sview->GetSelectionNode()->deselectAll();
	                  sview->GetSelectionNode()->select(p->getChild(4)) ; //get "geometry" node
                      //set selector to prior object
                      sdoc->obj_selector = myprior ;

					  //Attach the object
					  theApp.ObjDirection=1; //switch the direction
					  AttachObject();
					  theApp.ObjDirection=2; //..and set the previous direction
                   }
		           break;
				 }
	  }
	}
	else //only one object
    {
	   //set new object translation & rotation 
       SoDrawStyle	*ds = (SoDrawStyle *)obj_sep->getChild(0) ;
	   SoTranslation *trans = (SoTranslation *)sep->getChild(1) ;
	   SoRotation *rot	= (SoRotation *)sep->getChild(2) ;
       //appear new object
	   ds->style = SoDrawStyle::FILLED ;
	   trans->translation	= Transaxis ; //put selected object translation values to the new object
	   rot->rotation.setValue(Rotaxis ,Rotangle) ; //put selected object rotation values to the new object

	   sdoc->new_object = _NONE_ ;  //��� ���������� �� ������� click ��� �� ���������� �� �����������
    }

	//save new object attributes (get it from saved old-selected-replaced object)
	next_id      = mynext ;
	prior_id     = myprior ;
	carrier_id   = mycarrier ;
	carrier_side = mycarrier_side;
	object_side  = myobj_side;
	outlook      = myoutlook ;
	objNormal[0] = mynorm[0];
    objNormal[1] = mynorm[1];
	objNormal[2] = mynorm[2];

	SaveProperties();

    //select the new object..
	sview->GetSelectionNode()->deselectAll();
	sview->GetSelectionNode()->select(obj_sep->getChild(4)) ; //get "geometry" node
	sdoc->obj_selector = sdoc->ObjCount-1 ;
	//.. and set battering on..
	sdoc->BATTERING = true;

	sdoc->SetModifiedFlag() ;
	sdoc->UpdateAllViews(NULL);   
}



//Ungroup the selected object battering
void CGExternal::UnGroupObjects()
{
	int my_next, my_prev , meter;

	my_next = next_id ;  //get the selected object next number
	my_prev = prior_id ; //get the selected object previous number

	//first ungroup right objects of battering
	meter=0;
    while (my_next!=0)
	{
       CGExternal *nxt = ((CGExternal*)sdoc->Obj[my_next]);  //get next object

	   //get next object
	   my_next = nxt->next_id ;

	   nxt->prior_id = 0; 
	   nxt->next_id =0; //after getting the next pointer zero him
      
	   nxt->SaveProperties();

	   meter+=1; 
	}

	//secontary ungroup left objects...
    meter=0;
	while (my_prev!=0)
	{
       CGExternal *prv = ((CGExternal*)sdoc->Obj[my_prev]);  //get previous object
	   
	   //get prev object
	   my_prev = prv->prior_id ;

	   prv->next_id = 0;
       prv->prior_id =0; //after getting the prev pointer zero him

	   prv->SaveProperties();

	   meter+=1;
	}

	//..at end ungroup selected object
	next_id = 0;
	prior_id = 0;
	SaveProperties();

}

//copy ...
void CGExternal::CopyObject(int aanumber)
{
        CLib0 lib;
        SoSeparator *clone ; 

        //save aanumber
		sdoc->LastCopy = aanumber;

		//initialize buffer...
		if (sview->sep_buffer!=NULL) sview->sep_buffer->removeAllChildren();
		else sview->sep_buffer = new SoSeparator ;

	    //copy object (geometry & attributes nodes) from inventor to buffer...
	    SoSeparator *myroot = sdoc->root;
        SbName name = "GExternal"+lib.inttostr(aanumber) ; 

	    clone = (SoSeparator *)SoNode::getByName(name);

		SoNode *myGeom = clone->getChild(4); //get "Geometry" 
	    sview->sep_buffer->addChild( myGeom );
		SoNode *myAttr = clone->getChild(5); //get "Attributes" 
	    sview->sep_buffer->addChild( myAttr );

		//copy data...
		CGExternal *copied = ((CGExternal*)sdoc->Obj[aanumber]);
		((CGExternal *) sdoc->external_buffer) = copied ;
}

//paste ...
void CGExternal::PasteObject()
{	    
	    CLib0 lib;

	    CGExternal *ob ;
        SoSeparator *sep ;

        //prepare counters and data..
		ob = new CGExternal ;
	    sdoc->Obj[sdoc->ObjCount] = ob ; sdoc->ObjCount++ ;
		ob->sep = new SoSeparator ;
		sep = ob->sep ;
 

		//*****create pasted object...
	    SoTranslation	*trans	= new SoTranslation ;
	    SoRotation		*rot	= new SoRotation ;

		SoDrawStyle *ds = new SoDrawStyle ;
		sep->addChild(ds) ;
		ds->style = SoDrawStyle::INVISIBLE ;
	
	    sep->addChild ( trans ) ;
	    sep->addChild ( rot ) ;

	    SoPickStyle *ps = new SoPickStyle;
	    sep->addChild(ps) ;
        ps->style.setValue(SoPickStyle::SHAPE) ;
        
		//copy object (geometry & attributes) from buffer...
		SoNode *myGeom = sview->sep_buffer->getChild(0); //get "Geometry" 
	    sep->addChild( myGeom );
		SoNode *myAttr = sview->sep_buffer->getChild(1); //get "Attributes" 
	    sep->addChild( myAttr );
        //************ end of creation

		//finaly...set name & counters & data
	    ob->offset = sdoc->ob_offset ; 
		sdoc->ob_offset++ ;
		ob->name   = "GExternal" + lib.inttostr(sdoc->ObjCount-1); 

		ob->code   = sdoc->external_buffer->code ;
		ob->descr  = sdoc->external_buffer->descr ;

		int i;
		for ( i = 0 ; i < 10 ; i++ )
			ob->eid_id[i] = sdoc->external_buffer->eid_id[i];

		for ( i = 0 ; i < 3 ; i++ )
		{
			ob->left_base_point[i]	= sdoc->external_buffer->left_base_point[i] ;
			ob->right_base_point[i] = sdoc->external_buffer->right_base_point[i] ;
			ob->left_top_point[i]	= sdoc->external_buffer->left_top_point[i] ;
			ob->right_top_point[i]	= sdoc->external_buffer->right_top_point[i] ;
		}

		//get min..max
		ob->xmin = sdoc->external_buffer->xmin ;
		ob->ymin = sdoc->external_buffer->ymin ;
		ob->zmin = sdoc->external_buffer->zmin ;
		ob->xmax = sdoc->external_buffer->xmax ;
		ob->ymax = sdoc->external_buffer->ymax ;
		ob->zmax = sdoc->external_buffer->zmax ;

		sdoc->new_object = _EXTERNAL_;

		ob->ObjectToInventor(sdoc->root) ;

		//AfxMessageBox(lib.inttostr(sdoc->obj_selector));
 
        //��� �������� �� ���������� object � inventor 
		//����� ������� copy ��� "Geometry"  <---------------
  
        //so... select the copied (source) object..
		CGExternal *sObj = ((CGExternal*)sdoc->Obj[sdoc->LastCopy]);
		SoSeparator *source = ((CGExternal*)sdoc->Obj[sdoc->LastCopy])->sep ;
		sview->GetSelectionNode()->deselectAll();
	    sview->GetSelectionNode()->select(source->getChild(4)) ; //get "geometry" node
        //set selector
	    sdoc->obj_selector = sdoc->LastCopy ;  
	    //.. and set battering on..
	    sdoc->BATTERING = true;
 
    	sdoc->SetModifiedFlag() ;
    	sdoc->UpdateAllViews(NULL);  
}

//find if other objects is attached to this object
bool CGExternal::IsAttachedObject(int objno)
{
    int objs;
	bool attached = false ;
	int obj_sum = sdoc->ObjCount;

	//for objs=wallno because it is inpossible to have obj attached before this.
	for(objs = objno;objs < obj_sum ; objs++)
	{ 
      //WARNING : check for NULL pointers
	  if (sdoc->Obj[objs]!=NULL)
	  {
		//WARNING : the loop must be not check the object himself
		if ((sdoc->Obj[objs]->IsKindOf(RUNTIME_CLASS(CGExternal))) && (objs!=objno))
        {
          CGExternal *ext = ((CGExternal*)sdoc->Obj[objs]);
		  if (ext->carrier_id == objno ) 
		  {
			  attached = true ;
			  return attached; 
          }
        }
      }
	}
	return attached ;
}

//delete ...
void CGExternal::DeleteObject(int aanumber)
{
    CLib0 lib; 

    if (IsAttachedObject(aanumber)==false)
	{
		//deselect ...
	    sview->GetSelectionNode()->deselectAll();
        sdoc->obj_selector=-1;

        //delete object from inventor...
		SoSeparator *myroot = sdoc->root;
		SoSeparator *del_external;
        SbName name = "GExternal"+lib.inttostr(aanumber) ; 
		del_external = (SoSeparator *)SoNode::getByName(name);
		myroot->removeChild(del_external);

		//delete object from Object array
	    sdoc->Obj[aanumber]=NULL;
	}
	else
        AfxMessageBox("          Access denied.\n Other object(s) use this object.");

}

/////////////////////////////////////////////////////////////////////////////
// GExternalProp dialog


GExternalProp::GExternalProp(CWnd* pParent /*=NULL*/)
	: CDialog(GExternalProp::IDD, pParent)
{
	//{{AFX_DATA_INIT(GExternalProp)
	m_code = _T("");
	m_descr = _T("");
	m_xdist = 0.0f;
	m_yangle = 0.0f;
	m_ydist = 0.0f;
	m_leftdist = 0.0f;
	m_rightdist = 0.0f;
	m_x1dist = 0.0f;
	m_objLen = 0.0f;
	m_batLen = 0.0f;
	m_outlook = 0.0f;
	//}}AFX_DATA_INIT
}


void GExternalProp::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(GExternalProp)
	DDX_Text(pDX, IDC_CODE, m_code);
	DDX_Text(pDX, IDC_DESCR, m_descr);
	DDX_Text(pDX, IDC_XDIST, m_xdist);
    DDX_Text(pDX, IDC_YANGLE, m_yangle);	
	DDV_MinMaxFloat(pDX, m_yangle, 0.f, 360.f);
	DDX_Text(pDX, IDC_YDIST, m_ydist);
	DDV_MinMaxFloat(pDX, m_ydist, 0.f, 10000.f);
	DDX_Text(pDX, IDC_LEFT, m_leftdist);
	DDX_Text(pDX, IDC_RIGHT, m_rightdist);
	DDX_Text(pDX, IDC_X1DIST , m_x1dist);
	DDX_Text(pDX, IDC_OBJLEN, m_objLen);
	DDX_Text(pDX, IDC_BATLEN, m_batLen);
	DDX_Text(pDX, IDC_OUTLOOK, m_outlook);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(GExternalProp, CDialog)
	//{{AFX_MSG_MAP(GExternalProp)
        // NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// GExternalProp message handlers

