// GObject.cpp : implementation file
//

#include "stdafx.h"
#include "SYNTH.h"
#include "SYNTHDoc.h"
#include "lib0.h"
#include "GObject.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#include <Inventor/nodes/SoTranslation.h>
#include <Inventor/nodes/SoRotation.h>
#include <Inventor/nodes/SoPickStyle.h>
#include <Inventor/nodes/SoDrawStyle.h>

#define PI 3.1415926

/////////////////////////////////////////////////////////////////////////////
// CGObject

IMPLEMENT_DYNAMIC( CGObject, CObject )

CGObject::CGObject()
{
	carrier_id   = -1; //init with invalid values
	carrier_side = -1; 
	object_side  = -1; 
}

CGObject::~CGObject()
{
}

void CGObject::ObjectToInventor ( SoSeparator *root ) 
{
}

void CGObject::SaveProperties() 
{
	CLib0 lib ;
	CString soff = lib.inttostr(offset) ;

    //save box data to inventor

    // BASE PONTS
 /*   lib.setSoSFFloatProp ( attr, SbName("ssx0"+soff), ssx[0] ) ;
    lib.setSoSFFloatProp ( attr, SbName("ssy0"+soff), ssy[0] ) ;
	lib.setSoSFFloatProp ( attr, SbName("ssz0"+soff), ssz[0] ) ;
	lib.setSoSFFloatProp ( attr, SbName("ssx1"+soff), ssx[1] ) ;
	lib.setSoSFFloatProp ( attr, SbName("ssy1"+soff), ssy[1] ) ;
	lib.setSoSFFloatProp ( attr, SbName("ssz1"+soff), ssz[1] ) ;
	lib.setSoSFFloatProp ( attr, SbName("ssx2"+soff), ssx[2] ) ;
	lib.setSoSFFloatProp ( attr, SbName("ssy2"+soff), ssy[2] ) ;
	lib.setSoSFFloatProp ( attr, SbName("ssz2"+soff), ssz[2] ) ;
	lib.setSoSFFloatProp ( attr, SbName("ssx3"+soff), ssx[3] ) ;
	lib.setSoSFFloatProp ( attr, SbName("ssy3"+soff), ssy[3] ) ;
	lib.setSoSFFloatProp ( attr, SbName("ssz3"+soff), ssz[3] ) ;

    // UP POINTS
	lib.setSoSFFloatProp ( attr, SbName("ssx4"+soff), ssx[4] ) ;
	lib.setSoSFFloatProp ( attr, SbName("ssy4"+soff), ssy[4] ) ;
	lib.setSoSFFloatProp ( attr, SbName("ssz4"+soff), ssz[4] ) ;
	lib.setSoSFFloatProp ( attr, SbName("ssx5"+soff), ssx[5] ) ;
	lib.setSoSFFloatProp ( attr, SbName("ssy5"+soff), ssy[5] ) ;
	lib.setSoSFFloatProp ( attr, SbName("ssz5"+soff), ssz[5] ) ;
	lib.setSoSFFloatProp ( attr, SbName("ssx6"+soff), ssx[6] ) ;
	lib.setSoSFFloatProp ( attr, SbName("ssy6"+soff), ssy[6] ) ;
	lib.setSoSFFloatProp ( attr, SbName("ssz6"+soff), ssz[6] ) ;
	lib.setSoSFFloatProp ( attr, SbName("ssx7"+soff), ssx[7] ) ;
	lib.setSoSFFloatProp ( attr, SbName("ssy7"+soff), ssy[7] ) ;
	lib.setSoSFFloatProp ( attr, SbName("ssz7"+soff), ssz[7] ) ;
*/
}

void CGObject::InventorToObject ( SoSeparator *root ) 
{
	CLib0 lib ;
	CString soff = lib.inttostr(offset) ;

	//restore box data

	// BASE POINTS
	ssx[0] = lib.getSoSFFloatProp(SbName("ssx0"+soff)) ;
	ssy[0] = lib.getSoSFFloatProp(SbName("ssy0"+soff)) ;
	ssz[0] = lib.getSoSFFloatProp(SbName("ssz0"+soff)) ;
	ssx[1] = lib.getSoSFFloatProp(SbName("ssx1"+soff)) ;
	ssy[1] = lib.getSoSFFloatProp(SbName("ssy1"+soff)) ;
	ssz[1] = lib.getSoSFFloatProp(SbName("ssz1"+soff)) ;
	ssx[2] = lib.getSoSFFloatProp(SbName("ssx2"+soff)) ;
	ssy[2] = lib.getSoSFFloatProp(SbName("ssy2"+soff)) ;
	ssz[2] = lib.getSoSFFloatProp(SbName("ssz2"+soff)) ;
	ssx[3] = lib.getSoSFFloatProp(SbName("ssx3"+soff)) ;
	ssy[3] = lib.getSoSFFloatProp(SbName("ssy3"+soff)) ;
	ssz[3] = lib.getSoSFFloatProp(SbName("ssz3"+soff)) ;

    // UP POINTS
	ssx[4] = lib.getSoSFFloatProp(SbName("ssx4"+soff)) ;
	ssy[4] = lib.getSoSFFloatProp(SbName("ssy4"+soff)) ;
	ssz[4] = lib.getSoSFFloatProp(SbName("ssz4"+soff)) ;
	ssx[5] = lib.getSoSFFloatProp(SbName("ssx5"+soff)) ;
	ssy[5] = lib.getSoSFFloatProp(SbName("ssy5"+soff)) ;
	ssz[5] = lib.getSoSFFloatProp(SbName("ssz5"+soff)) ;
	ssx[6] = lib.getSoSFFloatProp(SbName("ssx6"+soff)) ;
	ssy[6] = lib.getSoSFFloatProp(SbName("ssy6"+soff)) ;
	ssz[6] = lib.getSoSFFloatProp(SbName("ssz6"+soff)) ;
	ssx[7] = lib.getSoSFFloatProp(SbName("ssx7"+soff)) ;
	ssy[7] = lib.getSoSFFloatProp(SbName("ssy7"+soff)) ;
	ssz[7] = lib.getSoSFFloatProp(SbName("ssz7"+soff)) ;

}

void CGObject::GetBox()
{
}

int CGObject::EditProperties ( CDocument *d, SoSeparator *root ) 
{
	return IDOK ;
}

void CGObject::AddNewObject(SbVec3f p_point,SbVec3f p_normal)
{
}

//****************  GENERAL COMMANDS  ******************
//Array routines
bool CGObject::IsArrayEqual(const int src[4], int dst[4])
{
	bool state;
	for (int i=0;i<4;i++)
      if (src[i]==dst[i]) state = true;
	                 else return false;
	return state;
}

void CGObject::ArrayEqual(const int src[4], int dst[4])
{
	for (int i=0;i<4;i++)
             (dst[i]=src[i]);
}

void CGObject::ZeroArray(int arr[4])
{
	for (int i=0;i<4;i++)
               (arr[i]=0);
}

void CGObject::ReverceArray(int dst[4])
{
  int r;

  r = dst[0];
  dst[0] = dst[1];
  dst[1] = r;

  r = dst[2];
  dst[2] = dst[3];
  dst[3] = r;
}

float CGObject::RadiansToMires(float r)
{
   float mires;

   mires = (360 / (2*PI)) * r ;

   return mires ;
}

float CGObject::MiresToRadians(float m)
{
   float rads;

   rads = m * ((2*PI) / 360 );

   return m ;
}

//****************** INVENTOR COMMANDS *************************

//make object visible 
void CGObject::MakeObjVisible()
{
     //make object invisible and unpickable
	 SoSeparator *mysep = sep ;	 //get node
	 
	 //set draw style
	 SoDrawStyle	*ds = (SoDrawStyle *)mysep->getChild(0) ;
     ds->style = SoDrawStyle::FILLED  ;
	 //set pick style
	 SoPickStyle *ps = (SoPickStyle *)mysep->getChild(3) ;
     ps->style.setValue(SoPickStyle::SHAPE) ;
}

//make object invisible
void CGObject::MakeObjInvisible()
{
     //make object invisible and unpickable
	 SoSeparator *mysep = sep ;	 //get node
	 
	 //set draw style
	 SoDrawStyle	*ds = (SoDrawStyle *)mysep->getChild(0) ;
     ds->style = SoDrawStyle::INVISIBLE  ;
	 //set pick style
	 SoPickStyle *ps = (SoPickStyle *)mysep->getChild(3) ;
     ps->style.setValue(SoPickStyle::UNPICKABLE) ;
}

//get translation
SbVec3f CGObject::GetTranslation()
{
    SbVec3f vals ;

    SoSeparator *mysep = sep ;
    SoTranslation *trans = (SoTranslation *)mysep->getChild(1) ;
    vals = trans->translation.getValue();

	return vals ;
}

//set translation
void CGObject::SetTranslation(SbVec3f vals)
{
	SoSeparator *mysep = sep ;
    SoTranslation *trans = (SoTranslation *)mysep->getChild(1) ;
	trans->translation	= vals;
}


//get the rotation angle...
float CGObject::GetRotationAngle()
{
    SbVec3f Rotaxis ;
	float Rotangle ;

	//get selected object rotation
	SoSeparator *mysep = sep ; //get object node
	SoRotation *ro = (SoRotation *)mysep->getChild(2) ;
    	   
    ro->rotation.getValue(Rotaxis , Rotangle); //get object rotation values

	return Rotangle ;
}

//set rotation angle ...
void CGObject::SetRotationAngle(float angle)
{
    SbVec3f Rotaxis ;

	//get selected object rotation
	SoSeparator *mysep = sep ; //get object node
	SoRotation *ro = (SoRotation *)mysep->getChild(2) ;

	SbRotation *sbrot = new SbRotation(SbVec3f(0,1,0),angle) ;
	ro->rotation.setValue(*sbrot) ;

}

//get the rotation axis...
SbVec3f CGObject::GetRotationAxis()
{
    SbVec3f Rotaxis ;
	float Rotangle ;

	//get selected object rotation
	SoSeparator *mysep = sep ; //get object node
	SoRotation *ro = (SoRotation *)mysep->getChild(2) ;
    	   
    ro->rotation.getValue(Rotaxis , Rotangle); 

	return Rotaxis ;
}

//set rotate axis ...
void CGObject::SetRotationAxis(SbVec3f axis)
{
    SbVec3f Rotaxis ;
	float Rotangle ;

	//get selected object rotation
	SoSeparator *mysep = sep ; //get object node

	SoRotation *ro = (SoRotation *)mysep->getChild(2) ;
    ro->rotation.getValue(Rotaxis , Rotangle);

	//set new rotation
    ro->rotation.setValue(axis ,Rotangle) ;
}



/*************************  SYNTHESIS COMMON ROUTINES   **********************/

void CGObject::SetCarrierSide(int side)
{
   carrier_side = side ;
}


void CGObject::GetCarrierSide()
{
   int refp[4];
   int mycarrier = carrier_id;
   int myside = carrier_side;

   CGObject *obj = ((CGObject*)sdoc->Obj[mycarrier]);

   switch (myside)
   {
      case _FRONT_ : ArrayEqual(front ,refp); break;
	  case _RIGHT_ : ArrayEqual(right ,refp); break;
	  case _BACK_  : ArrayEqual(back  ,refp); ReverceArray(refp); break;
	  case _LEFT_  : ArrayEqual(left  ,refp); break;
      case _TOP_   : ArrayEqual(top   ,refp); break;
      case _BOTTOM_: ArrayEqual(bottom,refp); break;
   }

   pointX1 = obj->ssx[refp[0]] ;
   pointY1 = obj->ssy[refp[0]] ;
   pointZ1 = obj->ssz[refp[0]] ;

   pointX2 = obj->ssx[refp[1]] ;
   pointY2 = obj->ssy[refp[1]] ;
   pointZ2 = obj->ssz[refp[1]] ;

}



void CGObject::SetObjectSide(int side)
{
   object_side = side ;
}

void CGObject::GetObjectSide()
{
   int refp[4];

   switch (object_side)
   {
      case _FRONT_ : ArrayEqual(front ,refp); break;
	  case _RIGHT_ : ArrayEqual(right ,refp); break;
	  case _BACK_  : ArrayEqual(back  ,refp); break; //�'���� ��� ��������� ��� �������
	  case _LEFT_  : ArrayEqual(left  ,refp); break; //���������� ������
      case _TOP_   : ArrayEqual(top   ,refp); break;
      case _BOTTOM_: ArrayEqual(bottom,refp); break;
   }


   obj_pointX1 = ssx[refp[0]] ;
   obj_pointY1 = ssy[refp[0]] ;
   obj_pointZ1 = ssz[refp[0]] ;

   obj_pointX2 = ssx[refp[1]] ;
   obj_pointY2 = ssy[refp[1]] ;
   obj_pointZ2 = ssz[refp[1]] ;

}


CGObject::GetObjectNormal(float *normx,float *normy,float *normz)
{
   int refp[4];
   float nx,ny,nz;

   switch (object_side)
   {
      case _FRONT_ : ArrayEqual(front ,refp); break;
	  case _RIGHT_ : ArrayEqual(right ,refp); break;
	  case _BACK_  : ArrayEqual(back  ,refp); ReverceArray(refp); break;
	  case _LEFT_  : ArrayEqual(left  ,refp); break;
      case _TOP_   : ArrayEqual(top   ,refp); break;
      case _BOTTOM_: ArrayEqual(bottom,refp); break;
   }

   CGLib0 *glib = new CGLib0 ;

	
   glib->GetPolyNormal ( ssx[refp[0]], ssy[refp[0]], ssz[refp[0]],
  					     ssx[refp[1]], ssy[refp[1]]+100, ssz[refp[1]],						
					     ssx[refp[1]], ssy[refp[1]], ssz[refp[1]],
					     &nx, &ny, &nz ) ;

   *normx = nx;
   *normy = ny;
   *normz = nz;

   return 0;
}

CGObject::GetCarrierNormal(float *normx,float *normy,float *normz)
{
   int refp[4];
   float X1,Y1,Z1,X2,Y2,Z2;
   float nx,ny,nz;

   CGObject *obj = ((CGObject*)sdoc->Obj[carrier_id]);

   
   switch (carrier_side)
   {
      case _FRONT_ : ArrayEqual(front ,refp); break;
	  case _RIGHT_ : ArrayEqual(right ,refp); break;
	  case _BACK_  : ArrayEqual(back  ,refp); ReverceArray(refp); break;
	  case _LEFT_  : ArrayEqual(left  ,refp); break;
      case _TOP_   : ArrayEqual(top   ,refp); break;
      case _BOTTOM_: ArrayEqual(bottom,refp); break;
   }

   X1 = obj->ssx[refp[0]] ;
   Y1 = obj->ssy[refp[0]] ;
   Z1 = obj->ssz[refp[0]] ;

   X2 = obj->ssx[refp[1]] ;
   Y2 = obj->ssy[refp[1]] ;
   Z2 = obj->ssz[refp[1]] ;

   CGLib0 *glib = new CGLib0 ;

	
   glib->GetPolyNormal ( X1, Y1, Z1,
  					     X2, Y2+100, Z2,						
					     X2, Y2, Z2,
					     &nx, &ny, &nz ) ;

   *normx = nx;
   *normy = ny;
   *normz = nz;

   return 0;
}


float CGObject::GetCarrierLength()
{
	float objdist;

	objdist =  sqrt( (pow( (pointX2 - pointX1), 2)) +
			         (pow( (pointY2 - pointY1), 2)) +
				     (pow( (pointZ2 - pointZ1), 2)) );

	return fabs(objdist);
}


//calculate lenght of object
float CGObject::GetObjectLength()
{
   float objdist ;
 
   //CLib0 lib; 


   objdist =  sqrt( (pow( (obj_pointX2-obj_pointX1), 2)) +
                    (pow( (obj_pointY2-obj_pointY1), 2)) +
		            (pow( (obj_pointZ2-obj_pointZ1), 2)) );


   //AfxMessageBox(lib.floattostr(objdist)); 

   return fabs(objdist);		   
}


/////////////////////////////////////////////////////////////////////////////
// CGObject message handlers
