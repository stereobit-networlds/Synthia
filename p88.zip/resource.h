//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SYNTH.rc
//
#define SYNTH_NEXT                      3
#define SYNTH_PRIOR                     4
#define IDD_ABOUTBOX                    100
#define SYNTH_SELECT_OBJ                102
#define IDR_MAINFRAME                   128
#define IDR_SYNTHTYPE                   129
#define SYNTH_WORLDBASE_PROP            132
#define SYNTH_WIZZ0                     136
#define SYNTH_ROOMBASE_PROP             137
#define SYNTH_ROOMWALL_PROP             138
#define SYNTH_GEXTERNAL_PROP            139
#define SYNTH_DELETE_OBJ                140
#define IDR_MYTBAR                      141
#define SYNTH_WIZZ1                     143
#define SYNTH_EXTRAWALL_PROP            144
#define IDM_VIEWPOINTS                  997
#define IDC_VIEWER                      998
#define IDC_ABOUT_TEXT                  999
#define IDC_NAME                        1001
#define IDC_ADDRESS                     1002
#define IDC_CITY                        1003
#define IDC_TEL                         1004
#define IDC_MHKOS0                      1011
#define IDC_ANGLE0                      1012
#define IDC_TOIXOMA0                    1013
#define IDC_ANGLE1                      1014
#define IDC_WIDTH                       1014
#define IDC_MHKOS1                      1015
#define IDC_HEIGHT                      1015
#define IDC_TOIXOMA1                    1016
#define SYNTH_CB_MONTELO                1016
#define IDC_PLAKAKI                     1016
#define SYNTH_CB_YLIKO                  1017
#define IDC_PLAKAKI1                    1017
#define SYNTH_CB_PORTAKI                1018
#define IDC_PLAKAKI2                    1018
#define SYNTH_CB_SYRTARI                1019
#define IDC_ANGLE2                      1020
#define SYNTH_CB_XEROYL                 1020
#define IDC_CODE                        1020
#define IDC_MHKOS2                      1021
#define SYNTH_CB_MPAZA                  1021
#define IDC_DESCR                       1021
#define IDC_TOIXOMA2                    1022
#define SYNTH_CB_ANTIK                  1022
#define IDC_YANGLE                      1022
#define IDC_TOPOTH                      1023
#define IDC_OUTLOOK                     1023
#define IDC_XDIST                       1024
#define IDC_YDIST                       1025
#define IDC_ANGLE3                      1026
#define IDC_LDIST                       1026
#define IDC_ZDIST                       1026
#define IDC_MHKOS3                      1027
#define IDC_RDIST                       1027
#define IDC_ROT                         1027
#define IDC_TOIXOMA3                    1028
#define IDC_LeftDIST                    1028
#define IDC_ANGLE4                      1029
#define IDC_ROTPARAM                    1029
#define IDC_UP                          1029
#define IDC_MHKOS4                      1030
#define IDC_LEFT                        1030
#define IDC_TOIXOMA4                    1031
#define IDC_RIGHT                       1031
#define IDC_ANGLE5                      1032
#define IDC_RADIO1                      1032
#define IDC_MHKOS5                      1033
#define IDC_RADIO2                      1033
#define IDC_TOIXOMA5                    1034
#define IDC_RADIO3                      1034
#define IDC_ANGLE6                      1035
#define IDC_X1DIST                      1035
#define IDC_RADIO4                      1035
#define IDC_MHKOS6                      1036
#define IDC_TOIXOMA6                    1037
#define IDC_OBJLEN                      1037
#define IDC_ANGLE7                      1038
#define IDC_BATLEN                      1038
#define IDC_RightDIST                   1038
#define IDC_MHKOS7                      1039
#define IDC_TOIXOMA7                    1040
#define ID_FILE_INFO                    32771
#define ID_VIEW_PICEDIT                 32795
#define ID_VIEW_SELECTIONMODE           32806
#define ID_VIEW_VIEWINGMODE             32807
#define ID_FILE_IMPORT                  32817
#define ID_FILE_RELOAD                  32818
#define SYNTH_NEW_SPHERE                32820
#define SYNTH_PROPERTIES                32821
#define SYNTH_KATAXKOYZIN               32822
#define SYNTH_SELECT                    32823
#define ID_OBJECT_LEFT                  32825
#define ID_OBJECT_RIGHT                 32827
#define ID_BUTTON32828                  32828
#define ID_BUTTON32829                  32829
#define ID_EXTENTED_CUT                 32830
#define ID_UNGROUP                      32831
#define ID_REPLACE                      32832
#define SYNTH_ADDWALL                   32833
#define SYNTH_JUMP                      32834

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        147
#define _APS_NEXT_COMMAND_VALUE         32835
#define _APS_NEXT_CONTROL_VALUE         1039
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
